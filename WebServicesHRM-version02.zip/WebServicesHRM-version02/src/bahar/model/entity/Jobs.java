package bahar.model.entity;

public class Jobs {
    private long JobID;
    private String Title;
    private String description;

   
}
