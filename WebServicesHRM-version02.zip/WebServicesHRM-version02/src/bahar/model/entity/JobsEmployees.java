package bahar.model.entity;

public class JobsEmployees {
    private long JobEmployeeID;
    private long employeeID;
    private long JobID;
}
